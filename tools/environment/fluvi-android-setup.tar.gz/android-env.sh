export JAVA_HOME=/workspace/.toolchains/jdk17
export ANDROID_HOME=/workspace/.toolchains/android-sdk
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export GRADLE_USER_HOME=/workspace/.toolchains/gradle
export PUB_CACHE=/workspace/.toolchains/pub-cache
export XDG_CONFIG_HOME=/workspace/.toolchains/config
export ANDROID_USER_HOME=/workspace/.toolchains/android-user
export CI=true
export PATH="$JAVA_HOME/bin:$ANDROID_HOME/cmdline-tools/19.0/bin:$ANDROID_HOME/platform-tools:/workspace/.toolchains/flutter/bin:$PATH"
export JAVA_TOOL_OPTIONS="-Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts $(python3 -c 'import os,urllib.parse; p=urllib.parse.urlsplit(os.environ["HTTPS_PROXY"]); print(" ".join(f"-D{x}.proxyHost={p.hostname} -D{x}.proxyPort={p.port}" for x in ["http","https"]))')"

export CHROME_EXECUTABLE=/usr/bin/chromium
unset ANDROID_SDK_HOME
