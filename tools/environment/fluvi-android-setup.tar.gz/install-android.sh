#!/usr/bin/env bash
set -euo pipefail
python3 - <<'PY'
from pathlib import Path
import subprocess, hashlib
b=Path('/workspace/.toolchains'); d=b/'downloads'; d.mkdir(parents=True,exist_ok=True)
def fetch(url,path,expected,algorithm):
    if not path.exists() or hashlib.new(algorithm,path.read_bytes()).hexdigest()!=expected:
        subprocess.run(['curl','-fSL',url,'-o',str(path)],check=True)
    assert hashlib.new(algorithm,path.read_bytes()).hexdigest()==expected
if not (b/'jdk17/bin/javac').exists():
    f=d/'jdk.tar.gz'
    fetch('https://github.com/adoptium/temurin17-binaries/releases/download/jdk-17.0.21%2B9/OpenJDK17U-jdk_x64_linux_hotspot_17.0.21_9.tar.gz',f,'8b9b611d917e3dfd8419d3566b5949226f69b052fed7e109c1368add1dfe8711','sha256')
    (b/'jdk17').mkdir(exist_ok=True)
    subprocess.run(['tar','-xzf',str(f),'--strip-components=1','-C',str(b/'jdk17')],check=True)
if not (b/'android-sdk/cmdline-tools/19.0/bin/sdkmanager').exists():
    f=d/'android-tools19.zip'
    fetch('https://dl.google.com/android/repository/commandlinetools-linux-13114758_latest.zip',f,'5fdcc763663eefb86a5b8879697aa6088b041e70','sha1')
    import tempfile
    with tempfile.TemporaryDirectory(dir=d) as t:
        subprocess.run(['unzip','-q',str(f),'-d',t],check=True)
        target=b/'android-sdk/cmdline-tools/19.0'; target.parent.mkdir(parents=True,exist_ok=True)
        (Path(t)/'cmdline-tools').rename(target)
latest=b/'android-sdk/cmdline-tools/latest'
if not latest.exists(): latest.symlink_to('19.0')
PY
source /workspace/.toolchains/android-env.sh
mkdir -p "$ANDROID_USER_HOME"
python3 - <<'PY'
import os,pathlib,urllib.parse
p=urllib.parse.urlsplit(os.environ['HTTPS_PROXY']); d=pathlib.Path(os.environ['GRADLE_USER_HOME']);d.mkdir(exist_ok=True)
f=d/'gradle.properties'
lines=f.read_text().splitlines() if f.exists() else []
prefixes=['org.gradle.workers.max=','systemProp.http.proxyHost=','systemProp.http.proxyPort=','systemProp.https.proxyHost=','systemProp.https.proxyPort=','systemProp.javax.net.ssl.trustStore=']
lines=[l for l in lines if not any(l.startswith(x) for x in prefixes)]
lines+=['org.gradle.workers.max=3','systemProp.javax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts']
for proto in ['http','https']: lines += [f'systemProp.{proto}.proxyHost={p.hostname}',f'systemProp.{proto}.proxyPort={p.port}']
f.write_text('\n'.join(lines)+'\n')
PY
python3 - <<'PY'
import subprocess,os
p=subprocess.run(['sdkmanager','--sdk_root='+os.environ['ANDROID_HOME'],'--licenses'],input='y\n'*100,text=True)
if p.returncode: raise SystemExit(p.returncode)
PY
sdkmanager --sdk_root="$ANDROID_HOME" 'platform-tools' 'platforms;android-35' 'platforms;android-36' 'build-tools;35.0.0' 'build-tools;36.0.0' 'ndk;28.2.13676358' 'cmake;3.22.1'
javac -version
flutter precache --android
