# Fluvi Android VM startup

Use existing /workspace/exptv2 checkout. Do not create a worktree unless requested.
Initialize each shell:

    source /workspace/.toolchains/android-env.sh

Installed: Temurin JDK 17.0.21, Flutter 3.41.4/Dart 3.11.1, Gradle 8.14, Kotlin plugin/compiler 2.2.20, Android platforms 35/36, build-tools 35/36, platform-tools, NDK 28.2.13676358, CMake 3.22.1, command line tools 19.0. SDK licenses accepted. JAVA_TOOL_OPTIONS uses inherited proxy and system Java CA trust. TLS/checksum checks remain enabled.

Build from /workspace/exptv2:

    flutter build apk --debug --no-pub

APK: build/app/outputs/flutter-apk/app-debug.apk. Build passed twice, repeated build 18.3 s. APK v2 signature and ZIP integrity passed. No emulator required.

Native tests from /workspace/exptv2/android:

    ./gradlew :fluvi-core:testDebugUnitTest :app:testDebugUnitTest --no-daemon --max-workers=3 --console=plain

Use normal command escalation outside workspace-only sandbox: Robolectric writes ~/.robolectric-download-lock and standard Maven caches. 51 core + 5 host tests passed, zero failures/errors/skips. Gradle can use daemons for builds; live processes must restart after snapshot restoration.

Full installer: /workspace/.toolchains/fluvi-full-install.sh. Android installer repeat execution passed. Install helpers remain outside the repository. If proxy settings change, rerun install-android.sh to refresh Gradle proxy properties. Flutter builds may generate android/gradlew.bat; remove only if newly generated and untracked. Source, manifests, tests and lockfiles were unchanged.

No accelerated emulator available: /dev/kvm missing; emulator/system image not installed. Release signing/build and device/performance tests not validated. Local APK builds are supported; GitHub Actions is optional CI.

Configuration save failed with draft_not_editable. Open a new setup chat from environment settings to save these installation/startup instructions. The archive includes helper files and the full install script; it does not include SDK binaries. Publication and fresh-task restoration of this Android setup have not been verified.
